**关于**

高斯tools (tool.guass.cc) 是一个旨在工具共享收集平台！！！   
初衷是为了收集资料方便各种姿势直接下载。
   

**捐赠**

如果你觉得本站还不错的话，就支持一下我。   
感谢捐赠者的肯定跟认可。   
<img src="https://tool.guass.cc/skm.jpg" width="45%">  
   

**纠错/修正文档**

部分资料来源互联网，如有侵权，望请您联系我们，非常感谢！   
联系邮箱：occupyme@foxmail.com

